package com.simplilearn.Phase3_Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsShoesBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportsShoesBootApplication.class, args);
	}

}
